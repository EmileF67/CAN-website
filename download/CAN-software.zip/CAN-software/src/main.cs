// -------------------------------------------------------------------
// Écrit avec beaucoup d'amour et de passion, et probablement quelques erreurs de jugement ainsi qu'un manque d'optimisation.
// Mais que voulez-vous, "Errare humanum est". :)
// - Emile
// -------------------------------------------------------------------


using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;

using Engine.Cadre;
using Engine.Input;
using Engine.MultipleChoices;
using Engine.AskNum;
using Extra.SendJson;

// Afficher véhicules choisis au fur et à mesure en fonction de la quantité


class Program
{
    // ---------------------------------------------------------------
    // Déclarations de fonctions utilitaires
    // ---------------------------------------------------------------

    // Permet de créer et de remplir un dictionnaire via un csv depuis le numéro du trajet passé en paramètre
    // Parcourt chaque ligne du csv et ajoute les informations extraites dans le dictionnaire
    // 
    // Le format du csv doit être le suivant :
    //     - Une ligne = un jour
    //     - Premier élément d'une ligne = numéro du jour
    //     - Chaque horaire regroupe 3 types d'informations :
    //           - L'horaire
    //           - Le bateau qui s'occupe de cet horaire
    //           - Un booléen qui représente la possibilité d'emmener un véhicule
    //
    // Voici un exemple de jour : 08:05;true ; 11:00;true ; 13:45;true ; 16:15;true ; 18:45;true
    static Dictionary<int, List<List<string>>> ExtraireDonneesCSV(int trajet)
    {
        // Déclaration
        string ligne;
        string[] temp;
        int i = 1, j = 0;
        Dictionary<int, List<List<string>>> dico = new Dictionary<int, List<List<string>>>();

        if(File.Exists($"Data/trajet{trajet}.csv"))
        {
            FileStream fs = new FileStream($"Data/trajet{trajet}.csv",FileMode.Open, FileAccess.Read);
            StreamReader donnees_trajet = new StreamReader(fs);
            while(!donnees_trajet.EndOfStream)
            {
                ligne = donnees_trajet.ReadLine();
                temp = ligne.Split(';');
                
                if (!dico.ContainsKey(i))
                {
                    dico[i] = new List<List<string>>(); // Si dico[i] n'existe pas alors on crée la liste
                }

                
                while(j+2 <= temp.Length) // 2 -> 1 ça fait crash
                {
                    List<string> tempL = new List<string>(); // Liste temporaire pour y mettre les infos en dessous
                    tempL.Add(temp[j]); // l'horaire
                    tempL.Add(temp[j+1]); // peut-on mettre des véhicules
                    dico[i].Add(tempL); // ajout de la liste au dico
                    j+=2;
                }
                j = 0;
                i++;
            }
        }

        return dico;
        
    }

    // Fonction qui renvoie une reservation qui prend en parametre le trajet et qui génére un dictionnaire via le json associé
    static Reservation Reserver(string nom, Dictionary<int, List<List<string>>> dico, int trajet)
    {
        // Déclaration
        List<string> info;
        Pair<string, string> datetime;
        string date;
        int jour;
        int heure;
        bool verif;

        // Demande du jour
        jour = DemanderNombre("Pour quelle date voulez-vous réserver ?", "/ Novembre / 2025", 1, 30);
        Console.SetCursorPosition(0, 2);
        Console.Write($"Date de réservation : {jour} / Novembre / 2025");

        // Demande de l'heure
        heure = DemanderHoraire(jour, dico);
        Console.SetCursorPosition(0, 3);
        Console.Write($"Horaire sélectionné : {dico[jour][heure][0]}");

        // Formatage + obtention de l'heure de la réservation
        info = FormatageHorraire(dico,jour,heure);
        datetime = getDate();

        // Si inférieur à 10 on ajoute un 0 devant pour l'ergonomie
        date = $"{info[0]}";
        if (int.Parse(info[0]) < 10) { date = $"0{date}"; }

        verif = info[2] == "true";

        Reservation reservation = new Reservation(nom, trajet, $"2025-11-{date}", info[1], $"{datetime.Second}{datetime.First}", verif);
        return reservation;
        
    }

    // Selectionne l'heure voulu dans un dictionnaire pour le trajet donné
    static List<string> FormatageHorraire(Dictionary<int, List<List<string>>> dico, int jour, int heure)
    {
        // Declaration
        List<string> info = new List<string>();
        string heureRes;
        string vehicules_autorises;
        
        List<List<string>> item = dico[jour];
        heureRes = item[heure][0];
        vehicules_autorises = item[heure][1];
        
        info.Add($"{jour}");
        info.Add(heureRes);
        info.Add(vehicules_autorises);
        
        return info;
    }

    // Permet d'obtenir la date de la réservation
    static Pair<string, string> getDate()
    {
        string hour;
        string date;
        
        long timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        DateTime dateT = DateTimeOffset.FromUnixTimeSeconds(timestamp).UtcDateTime;
        string[] both = dateT.ToString().Split(' ');

        date = both[0];
        hour = both[1];

        Pair<string, string> datetime = new Pair<string, string>(date, hour);
        return datetime;
    }

    // Extraire les horaires en fonction du jour pour PQ
    static List<Pair<string, bool>> ExtractHoraires(int jour, Dictionary<int, List<List<string>>> dict)
    {
        List<Pair<string, bool>> res = new List<Pair<string, bool>>();
        List<List<string>> horaires_jour = dict[jour];
        Pair<string, bool> temp;

        for (int i = 0; i < horaires_jour.Count; i++)
        {
            temp = new Pair<string, bool>
            (
                horaires_jour[i][0],
                horaires_jour[i][1]=="true"
            );
            res.Add(temp);
        }

        return res;
    }

    static void AfficherLogo(int x, int y)
    {
        string ligne;
        if (File.Exists("Assets/can-logo"))
        {
            FileStream fs = new FileStream("Assets/can-logo", FileMode.Open, FileAccess.Read);
            StreamReader logo = new StreamReader(fs);

            int i = 0;
            while (!logo.EndOfStream)
            {
                Console.SetCursorPosition(x, i);
                ligne = logo.ReadLine();
                Console.Write($"{ligne}");
                i++;
            }
        }
    }

    static string FormaterColonne(string texte, int largeur)
    {
        if (texte.Length > largeur)
        {
            // -3 pour laisser la place aux "..."
            return texte.Substring(0, largeur - 3) + "...";
        }
        else
        {
            return texte + new string(' ', largeur - texte.Length);
        }
    }

    static Reservation CreerRetour(Reservation aller, Dictionary<int, List<List<string>>> dictTrajetRetour)
    {
        // Attention /!\
        // Copie partielle -> Les éléments qui ne sont pas des types par défaut (ceux qui nécéssite une instance) ne sont pas une copie.
        // Par exemple : Une instance de liste sera la même dans <retour> et <aller>, mais un int sera une copié et indépendant.
        // 
        // Ici la liste de passagers et la liste de véhicules du retour seront la même instance que dans l'aller (mais pas une copie).
        // Cela nous arrange pour une bonne raison : on a pas besoin de les modifier ces deux listes, 
        // donc on garde la même instance de chacune d'entre elles.
        Reservation retour = aller;

        // Redemander la date (le jour uniquement)
        int jour = DemanderNombre("Pour quelle date voulez-vous réserver le retour ?", "/ Novembre / 2025", int.Parse(aller.date.Split('-')[2]), 30);
        Console.SetCursorPosition(0, 2);
        Console.Write($"Date de retour : {jour} / Novembre / 2025");

        // Demande de l'heure pour le retour
        int heure = DemanderHoraire(jour, dictTrajetRetour);
        Console.SetCursorPosition(0, 3);
        Console.Write($"Horaire de retour : {dictTrajetRetour[jour][heure][0]}");

        // Formatage + obtention de l'heure de la réservation
        List<string> info = FormatageHorraire(dictTrajetRetour, jour, heure);
        Pair<string, string> datetime = getDate();

        // Si inférieur à 10 on ajoute un 0 devant pour l'ergonomie
        string date = $"{info[0]}";
        if (int.Parse(info[0]) < 10) { date = $"0{date}"; }

        // Calculer l'ID du trajet retour (si 1 alors 2 | si 2 alors 1 | si 3 alors 4 | si 4 alors 3)
        //                          si impair         alors           sinon
        int idTrajetRetour = (aller.id % 2 == 1) ? aller.id + 1 : aller.id - 1;

        retour.id = idTrajetRetour;
        retour.date = $"2025-11-{date}";
        retour.heure = info[1];
        retour.horodatage = $"{datetime.Second}{datetime.First}";
        return retour;
    }

    // ---------------------------------------------------------------
    // Déclarations de structures
    // ---------------------------------------------------------------    


    struct Pair<T1, T2>
    {
        // Pair permet de faire un couple de valeur comme (a,b) en python mais modifiable
        // Equivalent à std::pair en c++
        // permet de soit retoouruner la valeur (get)
        // ou modifier la valeur (set)
        public T1 First { get; set; }
        public T2 Second { get; set; }

        public Pair(T1 first, T2 second)
        {
            First = first;
            Second = second;
        }
    }

    struct Passager
    {
        public string nom;
        public string prenom;
        public string code;

        public Passager(string nm, string pn, int age)
        {
            nom = nm;
            prenom = pn;
            
                 if (age >= 26)                 { code = "adu26p"; } 
            else if (age <= 25 && age >= 18)    { code = "jeu1825"; }
            else if (age <= 17 && age >= 4)     { code = "enf417"; }
            else if (age <= 3 && age >= 0)      { code = "bebe"; }
            else if (age == -1)                 { code = "ancomp"; }
            else                                { code = null; }       // Impossible mais on protège
        }
    }

    struct Vehicule
    {
        public string type;

        public Vehicule(string choix)
        {
            type = "trot"; // Valeur par défaut obligatoire pour protéger

            // Le numéro en fonction de l'ordre dans lequel chaque type à été ajouté dans choices dans la fonction DemanderVehicule.
            switch(choix)
            {
                case "Trotinette électrique":                 type = "trot";     break;
                case "Vélo ou remorque à vélo":               type = "velo";     break;
                case "Vélo électrique":                       type = "velelec";  break;
                case "Vélo cargo ou tandem":                  type = "cartand";  break;
                case "Deux roues <= 125cm3":                  type = "mobil";    break;
                case "Deux roues > 125cm3":                   type = "moto";     break;
                case "Voiture moins de 4m":                   type = "cat1";     break;
                case "Voiture de 4m à 4m39":                  type = "cat2";     break;
                case "Voiture de 4m40 à 4m79":                type = "cat3";     break;
                case "Voiture plus de 4m80":                  type = "cat4";     break;
                case "Camping car - Véhicule > 2m10 de haut": type = "camp";     break;
            }
        }
    }

    struct Reservation
    {
        public string nom;
        public int id;                    // Id de la ligne de bateau utilisée 
        public string date;               // Jour choisi
        public string heure;              // Heure choisie
        public string horodatage;         // Permet le stockage de l'heure actuelle
        public List<Passager> passagers;  // Liste contenant tous les passagers (animaux de compagnie inclus)
        public List<Vehicule> vehicules;  // Liste contenant tous les véhicules

        // Constructeur
        public Reservation(string nm ,int ide ,string dt ,string he ,string hV, bool vehicules_autorises)
        {
            nom = nm;
            id = ide;
            date = dt;
            heure = he;
            horodatage = hV;
            passagers = new List<Passager>();
            vehicules = new List<Vehicule>();

            // ---- Début de la récolte d'information ----
            // Passagers
            RemplirPassager(passagers);

            // Animaux de compagnie
            RemplirAnimaux(passagers);

            // Véhicules
            if (vehicules_autorises) {
                RemplirVehicules(vehicules);
            }       
        }
    }

    // ---------------------------------------------------------------   
    // Partie procédures utilitaires pour récolter des informations supplémentaires lors d'une réservation.
    // ---------------------------------------------------------------   

    // Cette procédure permet de demander le nombre de passagers souhaités puis de demander les informations nécessaires pour chacun de ces passagers
    // Utilisation de void car on passe une liste en argument, qui est passé automatiquement en référence, donc rien à retourner
    static void RemplirPassager(List<Passager> passagers)
    {
        // Déclaration
        string name;
        string pname;
        int age;
        int nbPassager;
        Passager passager;

        Console.Clear();

        // Indication du nom des colonnes
        Console.SetCursorPosition(0, 0);
        Console.Write($"Nom{new string(' ', 27)} Prénom{new string(' ', 24)} Age");
        Console.SetCursorPosition(0, 1);
        Console.Write($"{new string('-', 30)} {new string('-', 30)} {new string('-', 4)}");

        // Remplissage du tableau des passagers
        nbPassager = DemanderNombre("Nombre de passagers souhaité ?", "passager(s)", 1, 99);
        for (int i = 0; i < nbPassager; i++)
        {
            name = DemanderTexte($"Nom de la personne n°{i+1} ?", 50);
            pname = DemanderTexte($"Prénom de la personne n°{i+1} ?", 50);
            age = DemanderNombre($"Age de la personne n°{i+1} ?", "ans", 0, 130); // Sah y'a pas à être plus vieux que 130ans, c'est une dingz

            passager = new Passager(name,pname,age);
            passagers.Add(passager);

            Console.SetCursorPosition(0, 2+i);            // +2 car on affiche les noms des colonnes au dessus
            Console.Write($"{FormaterColonne(name, 30)} {FormaterColonne(pname, 30)} {age}");
        }
    }

    // Cette procédure permet de demander si l'on veut emmener des animaux de compagnie, puis le nombre qu'on veut emporter,
    // et enfin récolter les informations pour chacun d'entre eux
    static void RemplirAnimaux(List<Passager> passagers)
    {
        // Déclaration
        string name;
        string pname;
        Passager passager;

        bool animauxdeCompagnie = DemanderOuiNon("Emmener un ou plusieurs animaux de compagnie ?");
        Console.Clear();

        // Ajout des différents animaux de compagnie
        if (animauxdeCompagnie)
        {
            // Indication du nom des colonnes
            Console.SetCursorPosition(0, 0);
            Console.Write($"Nom{new string(' ', 27)} Prénom");
            Console.SetCursorPosition(0, 1);
            Console.Write($"{new string('-', 30)} {new string('-', 30)}");

            // Remplissage du tableau des passagers avec le nombre d'animaux entré
            int nbAnimauxDeCompagnie = DemanderNombre("Nombre d'animaux de compagnie souhaités", "animaux de compagnie", 1, 99);
            for (int i = 0; i < nbAnimauxDeCompagnie; i++) {
                name = DemanderTexte($"Nom de l'animal de compagnie n°{i+1} ?", 50);
                pname = DemanderTexte($"Prénom de l'animal de compagnie n°{i+1} ?", 50);

                passager = new Passager(name, pname, -1);
                passagers.Add(passager);

                Console.SetCursorPosition(0, 2+i);            // +1 car on affiche les noms des colonnes au dessus
                Console.Write($"{FormaterColonne(name, 30)} {pname}");
            }
        }
    }

    // Cette procédure permet de demander si l'on veut emmener des véhicules, puis le nombre de véhicules,
    // et enfin récolter le type de véhicule pour chaque véhicule à travers l'exécution du constructeur de la structure Vehicule
    static void RemplirVehicules(List<Vehicule> vehicules)
    {
        // Déclaration
        string choix;
        int qteVehi;
        int nbrExemplaireVehi;
        int ligne;
        Vehicule vehiRes;

        Console.Clear();

        bool reponse = DemanderOuiNon("Emmener un ou plusieurs véhicules ?");
        if (reponse)
        {
            // Indication du nom des colonnes
            Console.SetCursorPosition(0, 0);
            Console.Write($"Nom{new string(' ', 27)} Quantité");
            Console.SetCursorPosition(0, 1);
            Console.Write($"{new string('-', 30)} {new string('-', 9)}");

            // Remplissage du tableau des véhicules avec le nombre de véhicules souhaités
            qteVehi = DemanderNombre("Nombres de véhicules ?", "véhicule(s)", 1, 18);
            ligne = 0;
            while (qteVehi > 0)
            {
                choix = DemanderVehicule();
                nbrExemplaireVehi = DemanderNombre("Nombre de véhicules de cette catégorie ?", "exemplaire(s)", 1, qteVehi);
                for (int i = 0; i < nbrExemplaireVehi; i++)
                {
                    vehiRes = new Vehicule(choix);   // Va déterminer le type de véhicule en fonction du choix effectué
                    vehicules.Add(vehiRes);
                }
                qteVehi -= nbrExemplaireVehi;
                Console.SetCursorPosition(0, 2+ligne);
                Console.Write($"{choix}{new string(' ', 30-choix.Length)} {nbrExemplaireVehi}");
                ligne++;
            }
        }
    }

    // ---------------------------------------------------------------
    // Partie Génération du fichier JSON
    // ---------------------------------------------------------------


    // Génère le JSON de la réservation 
    static void genererJSONres(List<Reservation> listeReservations)
    {
        // Structure qui nous permet de
        StringBuilder sb = new StringBuilder();
        sb.Append("[");

        for (int i = 0; i < listeReservations.Count; i++)
        {
            var r = listeReservations[i];
            if (i > 0) sb.Append(",\n");

            sb.Append("\n  {");
            sb.Append("\n    \"reservation\": {");
            sb.AppendFormat("\n      \"nom\": \"{0}\",", EscapeJson(r.nom));
            sb.AppendFormat("\n      \"idLiaison\": {0},", r.id);
            sb.AppendFormat("\n      \"date\": \"{0}\",", EscapeJson(r.date));
            sb.AppendFormat("\n      \"heure\": \"{0}\",", EscapeJson(r.heure));
            sb.AppendFormat("\n      \"horodatage\": \"{0}\"", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.Append("\n    },");

            // Pour chaque passagers
            sb.Append("\n    \"passagers\": [");
            for (int p = 0; p < r.passagers.Count; p++)
            {
                var pg = r.passagers[p];
                if (p > 0) sb.Append(",");
                sb.AppendFormat("\n      {{\n        \"nom\": \"{0}\",\n        \"prenom\": \"{1}\",\n        \"codeCategorie\": \"{2}\"\n      }}", EscapeJson(pg.nom), EscapeJson(pg.prenom), EscapeJson(pg.code));
            }
            sb.Append("\n    ],");

            sb.Append("\n    \"vehicules\": [");
            // compter les véhicules par type
            Dictionary<string,int> counts = new Dictionary<string,int>();
            foreach (var v in r.vehicules)
            {
                if (counts.ContainsKey(v.type)) counts[v.type]++;
                else counts[v.type] = 1;
            }
            int vi = 0;
            foreach (var kv in counts)
            {
                if (vi > 0) sb.Append(",");
                sb.AppendFormat("\n      {{\n        \"codeCategorie\": \"{0}\",\n        \"quantite\": {1}\n      }}", EscapeJson(kv.Key), kv.Value);
                vi++;
            }
            sb.Append("\n    ]");

            sb.Append("\n  }");
        }

        sb.Append("\n]");

        File.WriteAllText("Reservation.json", sb.ToString());
    }

    // Fonction utilitaire réservée à genererJSONres()
    static string EscapeJson(string s)
    {
        if (s == null) return "";
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r");
    }

    // ---------------------------------------------------------------
    // Partie Fonction d'input d'information
    // ---------------------------------------------------------------

    static void Menu()
    {
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;

        // {DEBUG}
        // Console.Write($"w:{width}, h:{height}");

        int x_logo = width/2 - 41;
        int y_logo = 3;

        AfficherLogo(x_logo, y_logo);

        int x1_cadre = width / 2 - 25 - 10;
        int y1_cadre = height - height / 3 + 5;
        int x2_cadre = width / 2 + 25 + 10;
        int y2_cadre = y1_cadre + 4;
        Cadre cadre = new Cadre(x1_cadre, y1_cadre, x2_cadre, y2_cadre);

        Console.SetCursorPosition(x1_cadre+10, y1_cadre + 2);
        Console.Write("Appuyez sur <Entrée> pour faire une réservation...");
        cadre.Draw();

        Input input = new Input(0, 0, 0); // Coordonnées x:0, y:0 et d'une longueur de 0, donc on ne peut pas écrire dedans, on peut juste entrer
        while (!input.IsEntered())
        {
            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true);
                input.HandleKey(key);
            }
        }

        Console.Clear();
    }

    static string DemanderTexte(string text, int size)
    {
        // On récupère les dimensions actuelles de la console
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;

        // On calcule les bonne coordonnées du cadre
        int x1_cadre = 1;
        int y1_cadre = height - 6;
        int x2_cadre = width - 1;
        int y2_cadre = height - 2;

        // On créer nos instances du cadre, et de l'input avec les coordonnées calculées
        Cadre cadre = new Cadre(x1_cadre, y1_cadre, x2_cadre, y2_cadre);
        Input input = new Input(x1_cadre+3, y1_cadre+2, size - 4);

        // On affiche le cadre ici, car il n'y aura pas besoin de le réafficher dans la boucle
        cadre.Draw();

        // On affiche le titre de l'input ou du moins la valeur attendue
        Console.SetCursorPosition(x1_cadre+3, y1_cadre);
        Console.Write($"┤ {text} ├");

        input.Draw();

        string old = "";
        while (!input.IsEntered())
        {
            // On affiche le texte actuel de l'input que si il a changé
            if (old != input.GetText())
            {
                // On efface le curseur quand on dessine pour éviter le désagrément de le voir se téléporter
                Console.CursorVisible = false;
                input.Draw();
                // Puis on le réactive après avoir dessiné pour l'input
                Console.CursorVisible = true;
            }
            old = input.GetText();
            input.PlaceCursor();                    // On place le curseur à l'endroit où il est sensé se trouver
            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true);    // On récupère la touche appuyée si il y en a une.
                input.HandleKey(key);               // On la passe à input qui va agir en fonction de la touche.
            }

            // Attendre un certain temps pour économiser les ressources de la machine
            Thread.Sleep(5);    // 5ms
        }
        // Cette ligne permet d'effacer l'ancienne zone d'input sans effacer les informations notées en haut de l'écran.
        cadre.Clear();
        return input.GetText();
    }

    static int DemanderTrajet()
    {
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;

        int x1_cadre = 1;
        int y1_cadre = height - 9;
        int x2_cadre = width - 1;
        int y2_cadre = height - 2;

        string[] choices = {
            "Lorient   -> Groix",
            "Groix     -> Lorient",
            "Quiberon  -> Le Palais",
            "Le Palais -> Quiberon"
        };

        Cadre cadre = new Cadre(x1_cadre, y1_cadre, x2_cadre, y2_cadre);
        MultipleChoices multiplechoices = new MultipleChoices(x1_cadre+3, y1_cadre+2, 1, choices);

        cadre.Draw();

        Console.SetCursorPosition(x1_cadre+3, y1_cadre);
        Console.WriteLine("┤ Pour quel trajet voulez-vous réserver ? ├");

        multiplechoices.Draw();

        int old = 0;
        while (!multiplechoices.IsEntered())
        {
            if (old != multiplechoices.GetSelectedIndex())
            {
                multiplechoices.Draw();
            }
            old = multiplechoices.GetSelectedIndex();

            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true);
                multiplechoices.HandleKey(key);
            }

            Thread.Sleep(30);
        }
        cadre.Clear();
        return multiplechoices.GetSelectedIndex();
    }

    static int DemanderNombre(string text, string indentifiant, int min, int max)
    {
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;

        int x1_cadre = 1;
        int y1_cadre = height - 6;
        int x2_cadre = width - 1;
        int y2_cadre = height - 2;

        Cadre cadre = new Cadre(x1_cadre, y1_cadre, x2_cadre, y2_cadre);
        AskNum asknum = new AskNum(x1_cadre+3, y1_cadre+2, min, max);

        cadre.Draw();

        Console.SetCursorPosition(x1_cadre+3, y1_cadre);
        Console.WriteLine($"┤ {text} ├");

        asknum.Draw();
        Console.SetCursorPosition(x1_cadre+5, y1_cadre+2);
        Console.Write($" {indentifiant}");

        int old = min;
        while (!asknum.IsEntered())
        {
            if (old != asknum.GetNum())
            {
                asknum.Draw();
                Console.SetCursorPosition(x1_cadre+5, y1_cadre+2);
                Console.Write($" {indentifiant}");
            }
            old = asknum.GetNum();

            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true);
                asknum.HandleKey(key);
            }

            Thread.Sleep(30);
        }
        cadre.Clear();
        return asknum.GetNum();
    }

    static bool DemanderOuiNon(string text)
    {
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;

        int x1_cadre = 1;
        int y1_cadre = height - 6;
        int x2_cadre = width - 1;
        int y2_cadre = height - 2;

        string[] choices = {"Oui", "Non"};

        Cadre cadre = new Cadre(x1_cadre, y1_cadre, x2_cadre, y2_cadre);
        MultipleChoices multiplechoices = new MultipleChoices(x1_cadre+3, y1_cadre+2, 2, choices);

        cadre.Draw();

        Console.SetCursorPosition(x1_cadre+3, y1_cadre);
        Console.Write($"┤ {text} ├");

        multiplechoices.Draw();

        bool old = true;
        while (!multiplechoices.IsEntered())
        {
            if (old != (multiplechoices.GetSelectedIndex() == 0))
            {
                multiplechoices.Draw();
            }
            old = multiplechoices.GetSelectedIndex() == 0;

            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true);
                multiplechoices.HandleKey(key);
            }

            Thread.Sleep(30);
        }
        cadre.Clear();
        return (multiplechoices.GetSelectedIndex() == 0);
    }

    static string DemanderVehicule()
    {
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;

        int x1_cadre = 1;
        int y1_cadre = height - 9;
        int x2_cadre = width - 1;
        int y2_cadre = height - 2;

        string[] choices = {
            "Trotinette électrique",
            "Vélo ou remorque à vélo",
            "Vélo électrique",
            "Vélo cargo ou tandem",
            "Deux roues <= 125cm3",
            "Deux roues > 125cm3",
            "Voiture moins de 4m",
            "Voiture de 4m à 4m39",
            "Voiture de 4m40 à 4m79",
            "Voiture plus de 4m80",
            "Camping car - Véhicule > 2m10 de haut"
        };

        Cadre cadre = new Cadre(x1_cadre, y1_cadre, x2_cadre, y2_cadre);
        MultipleChoices multiplechoices = new MultipleChoices(x1_cadre+3, y1_cadre+2, 3, choices);

        cadre.Draw();

        Console.SetCursorPosition(x1_cadre+3, y1_cadre);
        Console.Write($"┤ Quel type de véhicule ├");

        multiplechoices.Draw();

        int old = 0;
        while (!multiplechoices.IsEntered())
        {
            if (old != multiplechoices.GetSelectedIndex())
            {
                multiplechoices.Draw();
            }
            old = multiplechoices.GetSelectedIndex();

            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true);
                multiplechoices.HandleKey(key);
            }

            Thread.Sleep(30);
        }
        cadre.Clear();
        return multiplechoices.GetSelectedChoice();   
    }

    static int DemanderHoraire(int jour, Dictionary<int, List<List<string>>> dico)
    {
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;

        int x1_cadre = 1;
        int y1_cadre = height - 8;
        int x2_cadre = width - 1;
        int y2_cadre = height - 2;

        List<Pair<string, bool>> horraires = ExtractHoraires(jour, dico);
        string[] choices = new string[horraires.Count];
        string temp_text;

        for (int i = 0; i < horraires.Count; i++)
        {
            if (horraires[i].Second) { temp_text = "Oui"; } 
            else { temp_text = "Non"; }
            choices[i] = $"{horraires[i].First}     {temp_text}{new string(' ', 30)}";
        }

        y1_cadre -= horraires.Count-1;

        Cadre cadre = new Cadre(x1_cadre, y1_cadre, x2_cadre, y2_cadre);
        MultipleChoices multiplechoices = new MultipleChoices(x1_cadre+3, y1_cadre+4, 1, choices);

        cadre.Draw();

        // Titre
        Console.SetCursorPosition(x1_cadre+3, y1_cadre);
        Console.Write("┤ Pour quelle heure voulez-vous réserver ? ├");

        // Colonnes du tableau
        Console.SetCursorPosition(x1_cadre+3, y1_cadre+2);
        Console.Write("Horraire  Possibilité d'emmener un véhicule");
        
        multiplechoices.Draw();

        int old = 0;
        while (!multiplechoices.IsEntered())
        {
            if (old != multiplechoices.GetSelectedIndex())
            {
                multiplechoices.Draw();
            }
            old = multiplechoices.GetSelectedIndex();

            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true);
                multiplechoices.HandleKey(key);
            }

            Thread.Sleep(30);
        }
        cadre.Clear();
        return multiplechoices.GetSelectedIndex();
    }

    // ---------------------------------------------------------------
    // Partie principale du programme
    // ---------------------------------------------------------------

    // Affiche un petit menu pendant <i> secondes pour proposer une expérience optimale.
    static void MessageDebut()
    {
        Console.Clear();

        string[] message = {"Pour une meilleure expérience, veuillez mettre le terminal en plein écran.", "Touche <Entrée> pour passer à la suite"};

        // Compteurs pour le décompte
        int i = 15;
        int temp = i;

        // Taille courante de la console (sera mise à jour en cas de redimensionnement)
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;

        // Pour comparer avec les anciennes valeurs
        int currentWidth;
        int currentHeight;

        // Affichage initial
        DrawFrameAndMessages(width, height, message);

        // Décompte de <i> secondes, en vérifiant le redimensionnement à chaque itération
        while (i > 0)
        {
            // Même si on ne redimensionne pas la console il faut afficher les lignes qui indique l'attente à nouveau toutes les secondes 
            int x = width / 2 - temp;
            DrawWaitingLine(x, height / 2 - 2, i);
            DrawWaitingLine(x, height / 2 + 3, i);

            // Attendre 1 seconde en vérifiant les touches chaque 100ms
            for (int j = 0; j < 20; j++)
            {
                // Si la fenêtre a été redimensionnée, on vide et on redessine
                currentWidth = Console.WindowWidth;
                currentHeight = Console.WindowHeight;
                if (currentWidth != width || currentHeight != height)
                {
                    // On attribue les nouvelles valeurs
                    width = currentWidth;
                    height = currentHeight;

                    // On prépare la console et on affiche le message et le cadre
                    Console.Clear();
                    DrawFrameAndMessages(width, height, message);
                }

                // On réaffiche les lignes qui indique l'attente
                x = width / 2 - temp;
                DrawWaitingLine(x, height / 2 - 2, i);
                DrawWaitingLine(x, height / 2 + 3, i);

                if (Console.KeyAvailable)
                {
                    var key = Console.ReadKey(true);
                    if (key.Key == ConsoleKey.Enter)
                    {
                        Console.Clear();
                        return;
                    }
                }
                Thread.Sleep(50);
            }
            i--;
        }

        Console.Clear();
    }

    // Dessine le cadre et le texte en fonction de la taille actuelle
    static void DrawFrameAndMessages(int width, int height, string[] message)
    {
        int x1 = width / 2 - message[0].Length / 2 - 2;
        int y1 = height / 2 - 3;
        int x2 = width / 2 + message[0].Length / 2 + 3;
        int y2 = height / 2 + 4;

        Cadre cadre = new Cadre(x1, y1, x2, y2);
        cadre.Draw();

        Console.SetCursorPosition(Math.Max(0, x1 + 2), Math.Max(0, y1 + 3));
        Console.Write(message[0]);
        Console.SetCursorPosition(Math.Max(0, x1 + 2), Math.Max(0, y1 + 4));
        int pad = message[0].Length / 2 - message[1].Length / 2;
        if (pad < 0) pad = 0;
        Console.Write($"{new string(' ', pad)}{message[1]}");
    }

    static void DrawWaitingLine(int x, int y, int i)
    {
        Console.SetCursorPosition(x, y);
        string equals = new string('=', i);
        string margin = new string(' ', 15 - i);
        Console.Write($"{margin}{equals} {i} {equals}{margin}");
    }

    static void InitialisationConsole()
    {
        // Windows utilise le cp850 dans son terminal (Code Page 850) or j'utilise des caractères unicodes, donc utf-8.
        // Je force donc le rendu en utf-8 (à voir aussi le contenu des fichiers run.bat et run.sh)
        SetUtf8Console();
        Console.Clear();
        Console.CursorVisible = false;
        MessageDebut();
    }

    static void SetUtf8Console()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding  = Encoding.UTF8;
    }

    static void Debut()
    {
        // Déclaration
        int nbRes = 0;
        int trajet;     // Liaison de la reservation (1 / 2 / 3 / 4 dans notre cas)
        string nom;
        bool rep = true;
        List<Reservation> listeReservations = new List<Reservation>();
        Dictionary<int, List<List<string>>> dictLG = null;
        Dictionary<int, List<List<string>>> dictGL = null;
        Dictionary<int, List<List<string>>> dictQP = null;
        Dictionary<int, List<List<string>>> dictPQ = null;

        Menu(); // Logo + <Entrée> pour passer à la suite

        nom = DemanderTexte("Sous quel nom réservez-vous ?", 50);
        Console.SetCursorPosition(0, 0);
        Console.Write($"Réservation au nom de : {nom}");

        while (rep)
        {
            // Selection du trajet
            trajet = DemanderTrajet()+1;
            Console.SetCursorPosition(0, 1);
            switch (trajet)
            {
                case 1:
                    if (dictLG == null) { dictLG = ExtraireDonneesCSV(trajet); }  // remplissage du dictionnaire des horraires Lorient --> Groix
                    Console.Write($"Trajet choisi : Lorient -> Groix");
                    listeReservations.Add(Reserver(nom, dictLG, trajet));
                    break;

                case 2:
                    if (dictGL == null) { dictGL = ExtraireDonneesCSV(trajet); }  // remplissage du dictionnaire des horraires Lorient --> Groix
                    Console.Write($"Trajet choisi : Groix -> Lorient");
                    listeReservations.Add(Reserver(nom, dictGL, trajet));
                    break;

                case 3:
                    if (dictQP == null) { dictQP = ExtraireDonneesCSV(trajet); }  // remplissage du dictionnaire des horraires Lorient --> Groix
                    Console.Write($"Trajet choisi : Quiberon -> Le Palais");
                    listeReservations.Add(Reserver(nom, dictQP, trajet));
                    break;

                case 4:
                    if (dictPQ == null) { dictPQ = ExtraireDonneesCSV(trajet); }  // remplissage du dictionnaire des horraires Lorient --> Groix
                    Console.Write($"Trajet choisi : Le Palais -> Quiberon");
                    listeReservations.Add(Reserver(nom, dictPQ, trajet));
                    break;
            }

            Console.Clear();
            bool retour = DemanderOuiNon("Voulez-vous qu'on vous complète une réservation pour le retour ?");
            if (retour)
            {
                // Accéder au dernier élément de la liste (la réservation à l'origine du retour)
                Dictionary<int, List<List<string>>> dictTrajetRetour = null;
                int idRetour = (trajet % 2 == 1) ? trajet + 1 : trajet - 1;
                
                switch (idRetour)
                {
                    case 2:
                        if (dictGL == null) { dictGL = ExtraireDonneesCSV(idRetour); }
                        dictTrajetRetour = dictGL;
                        break;
                    case 1:
                        if (dictLG == null) { dictLG = ExtraireDonneesCSV(idRetour); }
                        dictTrajetRetour = dictLG;
                        break;
                    case 4:
                        if (dictPQ == null) { dictPQ = ExtraireDonneesCSV(idRetour); }
                        dictTrajetRetour = dictPQ;
                        break;
                    case 3:
                        if (dictQP == null) { dictQP = ExtraireDonneesCSV(idRetour); }
                        dictTrajetRetour = dictQP;
                        break;
                }
                
                listeReservations.Add(CreerRetour(listeReservations[listeReservations.Count - 1], dictTrajetRetour));
            }
            Console.Clear();
            rep = DemanderOuiNon("Voulez-vous faire une autre réservation");
            nbRes++;
        }
        genererJSONres(listeReservations);

        string id = "";
        bool envoyer = DemanderOuiNon("Voulez-vous qu'on envoie directement le fichier comportant la réservation pour vous ?");
        if (envoyer)
        {
            SendJson sender = new SendJson("Reservation.json");
            id = sender.Run();
            Console.Clear();
            Console.WriteLine($"Les identifiants de vos réservations sont : {id}");
            Console.WriteLine("Merci de votre confiance, votre commande à été prise en compte !");
        }
    }


    static void Main()
    {
        // Mettre en place la console
        InitialisationConsole();
        Debut();
        Console.WriteLine("\nNous espérons vous revoir bientôt.\n- La CAN\n\n\n");
        // On rend le curseur
        Console.CursorVisible = true;
    }
}