#!/bin/bash

mono Bin/main.exe
read -p "Appuyez sur Entrée pour continuer..."