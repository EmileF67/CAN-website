#!/bin/bash

mcs main.cs Engine/* Extra/* -r:System.Net.Http.dll -out:Bin/main.exe