using System;

namespace Engine.Input
{
    public struct Input
    {   
        // Utilisation de short car les coordonnées
        // ne seront pas de grandes valeures
        private int x, y;
        private int length;

        private string input_text;
        private int cursor_pos;

        private bool entered;


        // Constructeur
        public Input(int x_, int y_, int length_)
        {
            x = x_;
            y = y_;
            length = length_;

            input_text = "";
            cursor_pos = 0;

            entered = false;
            if (length > 0) { Console.CursorVisible = true; }
        }


        // Fonction déplaçant le curseur avant que l'utilisateur saisisse du texte.
        public void PlaceCursor()
        {
            Console.SetCursorPosition(x + cursor_pos, y);
        }


        // Fonction retournant des valeurs uniques
        public bool IsEntered() => entered;
        public string GetText() => input_text;


        // Fonction Draw() pour afficher l'input
        public void Draw()
        {   
            // Effacer l'endroit de l'input en plaçant des espaces.
            Console.SetCursorPosition(x, y);
            Console.Write(new string(' ', length));

            // On affiche le contenu de l'input
            Console.SetCursorPosition(x, y);
            Console.Write(input_text);
        }


        // Cette fonction gère certaines touches du clavier. (Ici dans le cadre d'un input)
        public void HandleKey(ConsoleKeyInfo keyInfo)
        {
            // --- Caractères imprimables ---
            // keyInfo.KeyChar != 0 => c’est un vrai caractère
            if (!char.IsControl(keyInfo.KeyChar))
            {
                if (input_text.Length < length)
                {
                    input_text = input_text.Insert(cursor_pos, keyInfo.KeyChar.ToString());
                    cursor_pos++;
                }
                return;
            }

            // --- Backspace ---
            if (keyInfo.Key == ConsoleKey.Backspace)
            {
                if (cursor_pos > 0)
                {
                    input_text = input_text.Remove(cursor_pos - 1, 1);
                    cursor_pos--;
                }
            }

            // --- Delete ---
            else if (keyInfo.Key == ConsoleKey.Delete)
            {
                if (cursor_pos < input_text.Length)
                {
                    input_text = input_text.Remove(cursor_pos, 1);
                }
            }

            // --- Left arrow ---
            else if (keyInfo.Key == ConsoleKey.LeftArrow)
            {
                if (cursor_pos > 0)
                    cursor_pos--;
            }

            // --- Right arrow ---
            else if (keyInfo.Key == ConsoleKey.RightArrow)
            {
                if (cursor_pos < input_text.Length)
                    cursor_pos++;
            }

            // --- Home ---
            else if (keyInfo.Key == ConsoleKey.Home)
            {
                cursor_pos = 0;
            }

            // --- End ---
            else if (keyInfo.Key == ConsoleKey.End)
            {
                cursor_pos = input_text.Length;
            }

            // --- Enter ---
            else if (keyInfo.Key == ConsoleKey.Enter)
            {
                entered = true;
                Console.CursorVisible = false;
            }
        }
    }
}