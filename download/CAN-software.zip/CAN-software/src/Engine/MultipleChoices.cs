using System;


// Exemple d'utilisation :
//
// using Engine.MultipleChoices;
// MultipleChoices multiplechoices = new MultipleChoices(5, 7, 3, {"choix1", "choix2", "choix3", ...}) ;
//
namespace Engine.MultipleChoices
{
    // Utilité :
    // Permet d'afficher de nombreux choix selon 3 formats :
    //     - vertical       et pouvoir les parcourir vers le haut et le bas avec les flèches
    //     - horizontal     et pouvoir les parcourir vers la gauche et la droite avec les flèches
    //     - carré          et pouvoir les parcourir dans les deux axes (gauche/droite + haut/bas)
    //
    // On doit fournir les coordonnées x et y auxquelles l'élément doit s'afficher, le format d'affichage et un tableau de chaînes (les choix).
    public struct MultipleChoices
    {
        private int x, y;
        private int type;
        private string[] choices;
        private int selected;
        private bool entered;

        // Constructeur
        // type : 1:block (vertical) / 2:inline (horizontal) / 3:square-low
        public MultipleChoices(int x_, int y_, int type_, string[] choices_)
        {
            x = x_;
            y = y_;
            type = type_;
            choices = choices_ ?? new string[0];
            selected = 0;
            entered = false;
        }

        public bool IsEntered() => entered;
        public int GetSelectedIndex() => selected;
        public string GetSelectedChoice() => (choices != null && choices.Length > 0) ? choices[selected] : null;

        // Fonction Draw qui va afficher les différents choix avec le choix sélectionné surligné
        // L'affichage se fera également en fonction du type (1/2/3)
        public void Draw()
        {
            if (choices == null || choices.Length == 0)
                return;

            var originalBg = Console.BackgroundColor;
            var originalFg = Console.ForegroundColor;

            // Un switch va faciliter la relecture du programme.
            switch (type)
            {
                // Block (vertical list)
                case 1:
                    for (int i = 0; i < choices.Length; i++)
                    {
                        Console.SetCursorPosition(x, y + i);
                        if (i == selected)
                        {
                            Console.BackgroundColor = ConsoleColor.White;
                            Console.ForegroundColor = ConsoleColor.Black;
                        }
                        else
                        {
                            Console.BackgroundColor = originalBg;
                            Console.ForegroundColor = originalFg;
                        }
                        Console.Write(choices[i]);
                    }
                    break;

                // Inline (horizontal)
                case 2:
                    int pos = x;
                    for (int i = 0; i < choices.Length; i++)
                    {
                        Console.SetCursorPosition(pos, y);
                        if (i == selected)
                        {
                            Console.BackgroundColor = ConsoleColor.White;
                            Console.ForegroundColor = ConsoleColor.Black;
                        }
                        else
                        {
                            Console.BackgroundColor = originalBg;
                            Console.ForegroundColor = originalFg;
                        }
                        Console.Write(choices[i]);
                        pos += choices[i].Length + 1;
                    }
                    break;

                // square-low (grid proche d'un carré)
                case 3:
                    int n = choices.Length;
                    int rows = (int)Math.Ceiling(Math.Sqrt(n));
                    int cols = (int)Math.Ceiling((double)n / rows);

                    // Calculer la taille des colonnes pour aligner les blocs
                    int[] colWidths = new int[cols];
                    for (int col = 0; col < cols; col++)
                    {
                        int maxw = 0;
                        for (int r = 0; r < rows; r++)
                        {
                            int idx = col * rows + r;
                            if (idx >= n) break;
                            var t = $"[ {choices[idx]} ]";
                            if (t.Length > maxw) maxw = t.Length;
                        }
                        colWidths[col] = maxw;
                    }

                    // Calculer les positions de x pour chaque colonnes
                    int[] colX = new int[cols];
                    colX[0] = x;
                    for (int col = 1; col < cols; col++)
                        colX[col] = colX[col - 1] + colWidths[col - 1] + 1;

                    // Afficher la grille : on remplit les colonnes du haut vers le bas, 
                    // puis de la gauche vers la droite
                    for (int r = 0; r < rows; r++)
                    {
                        for (int col = 0; col < cols; col++)
                        {
                            int idx = col * rows + r;
                            if (idx >= n) continue;
                            var text = $"[ {choices[idx]} ]";
                            Console.SetCursorPosition(colX[col], y + r);
                            if (idx == selected)
                            {
                                Console.BackgroundColor = ConsoleColor.White;
                                Console.ForegroundColor = ConsoleColor.Black;
                            }
                            else
                            {
                                Console.BackgroundColor = originalBg;
                                Console.ForegroundColor = originalFg;
                            }
                            Console.Write(text.PadRight(colWidths[col]));
                        }
                    }
                    break;

                // Dans le cas où type n'est pas 1/2/3
                default:
                    int width = Console.WindowWidth;
                    int height = Console.WindowHeight;
                    Console.SetCursorPosition(Math.Max(0, width / 2 - 5), Math.Max(0, height / 2));
                    Console.Write($"{type} non reconnu");
                    Console.SetCursorPosition(Math.Max(0, width / 2 - 5), Math.Max(0, height / 2) + 1);
                    Console.Write("1 / 2 / 3");
                    break;
            }

            Console.BackgroundColor = originalBg;
            Console.ForegroundColor = originalFg;
        }


        // S'occupe de gérer les touches du clavier et agis en fonction de certaines touches :
        //     - Left Arrow     -> Déplace le curseur vers la gauche
        //     - Right Arrow    -> Déplace le curseur vers la droite
        //     - Down Arrow     -> Déplace le curseur vers le bas
        //     - Up Arrow       -> Déplace le curseur vers le haut
        //     - Enter          -> Change un booléen pour indiquer que le résultat à été entré
        public void HandleKey(ConsoleKeyInfo keyInfo)
        {
            if (choices == null || choices.Length == 0)
                return;
            if (keyInfo.Key == ConsoleKey.Enter)
            {
                entered = true;
                return;
            }

            // Action en fonction du type 1
            if (type == 1)
            {
                // --- Down arrow ---
                if (keyInfo.Key == ConsoleKey.DownArrow && selected < choices.Length - 1)
                    selected++;
                // --- Up arrow ---
                else if (keyInfo.Key == ConsoleKey.UpArrow && selected > 0)
                    selected--;

                return;
            }

            // Action en fonction du type 2
            if (type == 2)
            {   
                // --- Right arrow ---
                if (keyInfo.Key == ConsoleKey.RightArrow && selected < choices.Length - 1)
                    selected++;

                // --- Left arrow ---
                else if (keyInfo.Key == ConsoleKey.LeftArrow && selected > 0)
                    selected--;

                return;
            }

            // Action en fonction du type 3
            if (type == 3)
            {
                int n = choices.Length;
                int rows = (int)Math.Ceiling(Math.Sqrt(n));
                int cols = (int)Math.Ceiling((double)n / rows);

                int col = selected / rows;
                int row = selected % rows;

                // NOTE: GetIndexInColumn inplémenté en temps que méthode séparée. (l.260)

                // --- Up arrow ---
                if (keyInfo.Key == ConsoleKey.UpArrow)
                {
                    if (row > 0)
                    {
                        selected = col * rows + (row - 1);
                    }
                }

                // --- Down arrow ---
                else if (keyInfo.Key == ConsoleKey.DownArrow)
                {
                    if (row < rows - 1)
                    {
                        int idx = col * rows + (row + 1);
                        if (idx < n) selected = idx;
                    }
                }

                // --- Left arrow ---
                else if (keyInfo.Key == ConsoleKey.LeftArrow)
                {
                    if (col > 0)
                    {
                        int target = GetIndexInColumn(col - 1, row, rows, n);
                        if (target >= 0) selected = target;
                    }
                }

                // --- Right arrow ---
                else if (keyInfo.Key == ConsoleKey.RightArrow)
                {
                    if (col < cols - 1)
                    {
                        int target = GetIndexInColumn(col + 1, row, rows, n);
                        if (target >= 0) selected = target;
                    }
                }
            }
        }

        // Permet d'obtenir un index valide dans une colonne d'une ligne donnée (ou la plus proche en bas)
        private int GetIndexInColumn(int targetCol, int targetRow, int rows, int n)
        {
            int idx = targetCol * rows + targetRow;
            if (idx < n) return idx;

            // Si la ligne exacte n'existe pas, ça prend la dernière ligne existante dans la colonne.
            for (int r = rows - 1; r >= 0; r--)
            {
                int i = targetCol * rows + r;
                if (i < n) return i;
            }
            return -1;
        }
    }
}