using System;
using System.Collections.Generic;

// Exemple d'utilisation :
//
// using Engine.AskNum;
// AskNum asknum = new AskNum(5, 6, 0, 31);
//
namespace Engine.AskNum
{
    // Utilité :
    // Crée un champ de saisie numérique que l'on peut décrémenter ou incrémenter.
    public struct AskNum
    {
        private int x;
        private int y;
        private int min;
        private int max;
        
        private int num;
        private bool entered;

        // Constructeur
        public AskNum(int x_, int y_, int min_, int max_)
        {
            x = x_;
            y = y_;

            min = min_;
            max = max_;

            num = min;
            entered = false;
        }

        // Fonctions utilisées pour vérifier le statut d'entrée et obtenir la valeur entrée
        public bool IsEntered() => entered;
        public int GetNum() => num;


        // Permet d'afficher le numéro actuel aux coordonnées prévues
        public void Draw()
        {
            string text;
            if (num <= 9)
            {
                text = $"0{num}";
            }
            else
            {
                text = $"{num}";
            }
            Console.SetCursorPosition(x, y);
            Console.Write(text);

            // Afficher des flèches pleines pour indiquer une possibilité d'incrémentation
            Console.SetCursorPosition(x+1, y-1);
            if (num < max) { Console.Write("▲"); } 
            else { Console.Write(" "); }

            Console.SetCursorPosition(x+1, y+1);
            if (num > min) { Console.Write("▼"); }
            else { Console.Write(" "); }
        }


        // Permet de gérer certaines touches :
        //     - Down
        //     - Up
        //     - Enter
        public void HandleKey(ConsoleKeyInfo keyInfo)
        {
            // --- Down arrow ---
            if (keyInfo.Key == ConsoleKey.DownArrow && num > min)
            {
                num--;
            }

            // --- Up arrow ---
            else if (keyInfo.Key == ConsoleKey.UpArrow && num < max)
            {
                num++;
            }

            // --- Enter ---
            else if (keyInfo.Key == ConsoleKey.Enter)
            {
                entered = true;
            }
        }
    }
}