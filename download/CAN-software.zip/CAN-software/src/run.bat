@echo off
chcp 65001
mono Bin\main.exe
pause