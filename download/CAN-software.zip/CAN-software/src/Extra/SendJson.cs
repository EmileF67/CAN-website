using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

// Utilisation :
// SendJson sender = new SendJson("chemin/vers/fichier.json");
// string id = sender.Run();
namespace Extra.SendJson
{
    public struct SendJson
    {
        private string filePath;
        private string url;

        // --- CONSTRUCTEUR ---
        public SendJson(string filePath_)
        {
            filePath = filePath_;
            url = "https://can.iutrs.unistra.fr/";
        }

        // --- METHODE PRINCIPALE ---
        public string Run()
        {
            // Déclaration
            string resultat;

            try
            {
                // Mono ne supporte pas certaines surcharges HttpClientHandler
                // On force la désactivation SSL globale
                ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };    // On désactive totalement la vérification TLS -> Certificat accepté même si il est frauduleux ou falsifié.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;                      // Certains serveurs Https n'acceptent pas TLS 1.0 ou TLS 1.1, donc on force TLS 1.2

                resultat = EnvoyerEtExtraireIdAsync(url, filePath).Result;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex);
                Console.WriteLine("Appuyez sur <Entrée> pour continuer...");
                Console.ReadLine();
                resultat =  null;
            }

            return resultat;
        }

        // ---- ENVOI & EXTRACTION ----
        private static async Task<string> EnvoyerEtExtraireIdAsync(string url, string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Fichier JSON introuvable", filePath);

            // Déclaration
            string ids = null;

            // Le using en C# est une construction pratique pour s’assurer que les objets “disposables” sont fermés ou libérés automatiquement à la fin du bloc.
            // Donc si un objet implémente l'interface "IDisposable" comme HttpClient par exemple, il est disposable.
            // Quand le bloc se termine, la méthode Dispose() est appelée automatiquement sur l'objet.
            //
            // StreamContent encapsule un FileStream créé par File.OpenRead(filePath), mais Dispose() de StreamContent va aussi fermer le FileStream automatiquement. Donc pas de fuite de fichiers ouverts ici, tout est propre.
            using (HttpClient httpClient = new HttpClient())
            using (MultipartFormDataContent form = new MultipartFormDataContent())
            using (StreamContent fileContent = new StreamContent(File.OpenRead(filePath)))
            {
                fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

                // Le champ s’appel "jsonFile"
                form.Add(fileContent, "jsonFile", Path.GetFileName(filePath));

                Console.WriteLine("Envoi du fichier au serveur... Veuillez patienter.");
                HttpResponseMessage response = await httpClient.PostAsync(url, form);

                string html = await response.Content.ReadAsStringAsync();

                // Extraction des identifiants : peut être plusieurs séparés par virgule
                Match match = Regex.Match(
                    html,
                    @"Identifiants\s+de\s+la\s+réservation\s*:\s*([\d,\s]+)",
                    RegexOptions.IgnoreCase
                );

                if (match.Success)
                {
                    ids = match.Groups[1].Value.Replace(" ", "");
                }
            }

            return ids;
        }
    }
}
