# CAN Software | C#



## Compiler :

La commande de compilation est la suivante :
```bash
mcs main.cs Engine/* Extra/* -r:System.Net.Http.dll -out:Bin/main.exe
```
Mais **compile.sh** et **compile.bat** pour linux et windows respectivement sont déjà adaptés pour faire le travail automatiquement.


## Executer

La commande d'exécution est la suivante :
```bash
mono main.exe
```
Mais comme précédemment, **run.sh** et **run.bat** font le travail automatiquement.
Il est même très recommandé d'utiliser run.bat pour Windows car la commmande suivant est exécutée :
```bat
chcp 65001
```
Elle permet de basculer l'encodage du terminal Windows de cp850 (cp pour Code Page) à l'UTF-8 qui est nécessaire pour le bon fonctionnement du programme.


## Simple résumé

### Sur windows :
```cmd
compile.bat
run.bat
```

### Sur Linux ou systèmes Unix
```
compile.sh
run.sh
```
