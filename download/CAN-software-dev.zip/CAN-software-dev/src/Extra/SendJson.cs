using System;
using System.IO;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


// Utilisation :
// SendJson sender = new SendJson("chemin/vers/fichier.json");
// string id = sender.Run();
//
namespace Extra.SendJson
{
    public struct SendJson
    {
        private string filePath;
        private string url;

        // ---- CONSTRUCTEUR ----
        public SendJson(string filePath)
        {
            this.filePath = filePath;

            // URL du serveur (modifiable si besoin)
            this.url = "https://can.iutrs.unistra.fr/";
        }

        // ---- METHODE PRINCIPALE ----
        // Appel bloquant pour rester compatible avec mcs
        public string Run()
        {
            try
            {
                return EnvoyerEtExtraireIdAsync(url, filePath).Result;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
                return null;
            }
        }

        // ---- ENVOI & EXTRACTION ----
        private static async Task<string> EnvoyerEtExtraireIdAsync(string url, string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Fichier JSON introuvable", filePath);

            HttpClient httpClient = new HttpClient();

            using (MultipartFormDataContent form = new MultipartFormDataContent())
            using (StreamContent fileContent = new StreamContent(File.OpenRead(filePath)))
            {
                fileContent.Headers.ContentType =
                    new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

                // Le champ s’appel "jsonFile"
                form.Add(fileContent, "jsonFile", Path.GetFileName(filePath));

                Console.WriteLine("Envoi du fichier au serveur...");
                HttpResponseMessage response = await httpClient.PostAsync(url, form);

                string html = await response.Content.ReadAsStringAsync();

                Console.WriteLine("Réponse du serveur reçue.");

                // Extraction du nombre
                Match match = Regex.Match(html, @"Identifiants de la réservation\s*:\s*(\d+)");

                if (match.Success)
                    return match.Groups[1].Value;
            }

            return null;
        }
    }
}
