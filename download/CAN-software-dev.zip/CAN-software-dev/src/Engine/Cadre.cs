using System;

namespace Engine.Cadre
{
    public struct Cadre
    {
        // Ajout de private, pour éviter qu'on puisse accéder 
        // et modifier ces variables hors de la classe.
        private int x1, y1, x2, y2;

        // Constructeur (publique obligatoire)
        public Cadre(int x1_, int y1_, int x2_, int y2_)
        {
            x1 = x1_;
            y1 = y1_;
            x2 = x2_;
            y2 = y2_;
        }

        // Efface tout l'intérieur du cadre
        public void Clear()
        {
            string espaces = new string(' ', x2 - x1);      // déclarer ici comme ça on ne recréer pas à chaque fois la chaine
            for (int i = y1; i <= y2; i++)
            {
                Console.SetCursorPosition(x1, i);
                Console.Write(espaces);
            }
        }

    
        // Fonction Draw
        // Elle permet d'afficher le cadre en lui-même sur l'écran aux coordonnées
        // préalablement entrées en argument du constructeur. (x1, y1, x2, y2)
        public void Draw()
        {
            // Ligne du haut
            Console.SetCursorPosition(x1, y1);
            Console.WriteLine("╭" + new string('─', x2 - x1 - 2) + "╮");

            // Côtés
            for (int i = y1 + 1; i < y2; i++)
            {
                Console.SetCursorPosition(x1, i);
                Console.Write("│");

                Console.SetCursorPosition(x2 - 1, i);
                Console.Write("│");
            }

            // Ligne du bas
            Console.SetCursorPosition(x1, y2);
            Console.WriteLine("╰" + new string('─', x2 - x1 - 2) + "╯");
        }
    }
}
