#!/bin/bash

mcs main.cs Engine/*