# CAN Software | C#



## Compiler :

```bash
mcs main.cs Engine/*.cs -out:main.exe
```

## Executer
```bash
mono main.exe
# Ne pas utiliser ./main.exe
```
